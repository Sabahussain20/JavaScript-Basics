//DOCUMENT
//access by ID

document.getElementById("bg").style.background="pink"

//access by Class
document.querySelector(".btn").style.background="purple"
document.querySelector(".btn").style.color="white"
document.querySelector(".nav").style.background="purple"
//access by tag name
document.getElementsByTagName('h1')[0].style.fontSize="30px"

//alert('HELLO WORLD')

//document.write('HELLO WORLD')
//CONSOLE API 
console.log('HELLO WORLD')
console.warn('This is a warning')
console.error('This is an error')
//console.assert(4==(2+2))
//console.clear

//PRIMITIVE DATATYPES
var num1 = 5;
var num2 = 6.78;
console.log(num1+num2);
var str ="String in Double quotation"
var str2='String in single quotation'



//BOOLEAN
var a=true;
var b=false;
console.log(a);
console.log(b);

//UNDEFINED and NULL

var und;
console.log(und);

var a=null;
console.log(a);

//REFERENCE DATATYPE
//var array=[2,4,6,8,10];
var array=["saba","ayesha","zara","ashna"]
console.log(array[0]);
console.log(array);
//OBJECTS
var marks={
    saba:78,
    anita:24,
    sara:90
    }
    console.log(marks);

//ARITHEMETIC OPERATORS
var a=50;
var b=5;
console.log("The value of a+b is",a+b);
console.log("The value of a-b is",a-b);
console.log("The value of a*b is",a*b);
console.log("The value of a/b is",a/b);

//ASSIGNMENT OPERATORS
var c=b;
c+=2;
// c-=2;
// c*=2;
// c/=2;
console.log(c);

//COMPARISION OPERATORS
var a=23;
var b=35;
console.log(a==b);
console.log(a<b);
console.log(a>b);
console.log("& Operator");
//LOGICAL OPERATORS
console.log(true && true);
console.log(true && false);
console.log(false && true);
console.log(false && false);
console.log("OR Operator");
console.log(true || true);
console.log(true || false);
console.log(false|| true);
console.log(false || false);
console.log("NOT Operator");
console.log(!true);
console.log(!false);

//FUNCTIONS
function avg(a,b)
{
    return a+b/2;
}
c=avg(34,67);
c2=avg(45,60);
console.log(c,c2);

//CONDITIONAL STATEMENTS 
var num=42;
if(num>2)
console.log("Number is greater than 2");
else if(num<2)
console.log("Number is less than 2");
else
console.log("Number is equal to 2")

//LOOP
//for-loop
var array=[1,2,3,4,5,6,7,8,9,10];
/*for(var i=0;i<array.length;i++)
{
    console.log(array[i]);
}
*/

//foreach-loop
/*array.forEach(function(element){
    console.log(element);
})*/

//LET-- has scope in a block. Now use in JS more than var
let i=0;
/*while(i<array.length)
{
    console.log(array[i]);
    i++;
}*/
//DO-WHILE loop. Must be executed atleast one time
do{
    console.log(array[i]);
    i++;
}
while(i<array.length)
//EVENTS
function displayDate() {
    document.getElementById("second").innerHTML = Date();
  }

function BulbOn()
{
    document.getElementById('myImage').src='bulbon.png';
}
function BulbOff()
{
    document.getElementById('myImage').src='bulboff.png'
}
//BREAK
var array=[1,2,3,4,5,6,7];
for(var j=0; j<array.length;j++)
{
    if(j==3)
    {
        break;
    }
    console.log(array[j]);
    
}
//CONTINUE
for(var j=0; j<array.length;j++)
{
    if(j==3)
    {
        continue;
    }
    console.log(array[j]);
    
}
//Array Methods
var arr=[1,"saba",null,true,34.67];
//arr.pop(); --> delete last element
//arr.shift(); --> delete first element
//arr.push('edev'); --> push edev in last
//push edev at first 
arr.unshift('edev'); 
console.log(arr);
//Sort
var newarr=[5,3,2,1,0];
console.log(newarr.sort());

//Clock Function 
function clock()
{
    let a,date,time;
    const options={weekday:'long',year:'numeric',month:'long',day: 'numeric'}
setInterval(() => {

        a=new Date();
         date=a.toLocaleDateString(undefined,options);
         time=a.getHours() + ':' + a.getMinutes() + ':' + a.getSeconds();
        document.getElementById('time').innerHTML = "Current Time is:  "+ time +"<br> on "+ date;
        
    }, 1000);
document.getElementById("time").style.color="purple"
document.getElementById("time").style.fontSize="25px"
document.getElementById("clock").style.color="white"
document.getElementById("clock").style.background="purple"

}
//Hoisting: a variable can be declared after it has been used.
function Hoisting()
{
      x = 5; 
    elem = document.getElementById("hoisting").innerHTML="The value of Hoisted x is "+x;  
    var x; 
    document.getElementById("heading").style.color="white"
     document.getElementById("heading").style.fontSize="25px";
}


//Math
function myMath()
{
document.getElementById("math").innerHTML = 
"<p><b>Math.E:</b> " + Math.E + "</p>" +
"<p><b>Math.PI:</b> " + Math.PI + "</p>" +
"<p><b>Math.SQRT2:</b> " + Math.SQRT2 + "</p>" +
"<p><b>Math.SQRT1_2:</b> " + Math.SQRT1_2 + "</p>" +
"<p><b>Math.LN2:</b> " + Math.LN2 + "</p>" +
"<p><b>Math.LN10:</b> " + Math.LN10 + "</p>" +
"<p><b>Math.LOG2E:</b> " + Math.LOG2E + "</p>" +
"<p><b>Math.Log10E:</b> " + Math.LOG10E + "</p>";
}
//Slide Show using JS

// var i=0;
// var images=[];
// var time=2000;
// images[0]='pic1.jpg';
// images[1]='pic2.png';
// images[2]='pic3.jpg';
// images[3]='pic4.jpg';
//  function changeImage()
//  {
//      document.slide.src=images[i];
//      if(i<images.length-1)
//      {
//          i++;

//      }
//      else{
//          i=0;
//      }
//      setTimeout("changeImage()",time);
//     }
//     window.onload=changeImage;

//ESCAPE CHARACTERS
let txt = "We are \"Vikings\"";
console.log(txt);

//INDEX OF
let txt = "abcdefghijklm";
let pos = txt.indexOf("h");
console.log(pos);

//Slice Method
let txt = "I can eat bananas all day";
let x = txt.slice(10, 17);
console.log(x);

//REPLACE STRING
let txt = "Hello World";
txt = txt.replace("Hello", "Welcome");
console.log(txt);

//TO UPPER CASE & LOWER CASE
let txt = "Hello World";
txt = txt.toUpperCase();
console.log(txt);

let txt = "HELLO WORLD";
txt = txt.toL();
console.log(txt);
//Splice Method
const fruits = ["Banana", "Orange", "Apple", "Kiwi"];
fruits.splice(1);
console.log(fruits);